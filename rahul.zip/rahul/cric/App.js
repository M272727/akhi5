import './App.css';

const cricketers = [
  { name: "Sachin Tendulkar", age: 47, runs: 18426, wickets: 154 },
  { name: "Virat Kolhi", age: 52, runs: 3154, wickets: 708 },
  { name: "Mahendra Singh Dhoni", age: 52, runs: 11953, wickets: 0 },
];
function Cricket(props) {
  return (
    <div>
      {props.cricketers.map((player, index) => (
        <div key={index}>
          <h3>{player.name}</h3>
            <p>Age: {player.age}</p>
            <p>Runs: {player.runs}, Wickets: {player.wickets}</p>
            </div> ))}
            </div>
  );
}
function App() {
  return (
    <div className="App">
      <h2>Cricketers List:</h2>
      <Cricket cricketers={cricketers} />
    </div>
  )
}


export default App;
