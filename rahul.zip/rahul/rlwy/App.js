import './App.css';
import React , {useState} from 'react';

function App() {
  const [formdata,setformdata]=useState({
    name:'',
    pnr:'',
    date_Of_booking:'',
    start_date: '',
    end_date:''
  });

  const [submittedData, setSubmittedData]=useState(null);

  const handleChange = (e) => {
    const {name,value} = e.target;
    setformdata(prev => ({
      ...prev,
      [name]: value
  }));
};

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmittedData(formdata);
    setformdata({
      name:'',
      pnr:'',
      date_Of_booking:'',
      start_date: '',
      end_date:''
    })
  }

  return (
    <div className="App">
      <h2>Railway Reservation system</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Name:</label><br />
          <input name="name" value={formdata.name} onChange={handleChange} required />
        </div>
        <div>
          <label>pnr:</label><br />
          <input name="pnr" value={formdata.pnr} onChange={handleChange} required />
        </div>
        <div>
          <label>date_Of_booking:</label><br />
          <input name="date_Of_booking" value={formdata.date_Of_booking} onChange={handleChange} required />
        </div>
        <div>
          <label>start_date:</label><br />
          <input name="start_date" value={formdata.start_date} onChange={handleChange} required />
        </div>
        <div>
          <label>end_date:</label><br />
          <input name="end_date" value={formdata.end_date} onChange={handleChange} required />
        </div>
        <button type="submit">Submit</button>
      </form>

    {submittedData && (
      <div>
        <h3>Submitted data : </h3>
        <p><strong>Name:</strong> {submittedData.name}</p>
        <p><strong>pnr:</strong> {submittedData.pnr}</p>
        <p><strong>date_Of_booking:</strong> {submittedData.date_Of_booking}</p>
        <p><strong>start_date:</strong> {submittedData.start_date}</p>
        <p><strong>end_date:</strong> {submittedData.end_date}</p>
        </div>
    )}
    </div>
  );
}

export default App;
