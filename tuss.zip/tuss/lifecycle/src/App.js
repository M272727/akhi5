import React from 'react';
import LifecycleDemo from './components/LifecycleDemo';

function App() {
  return (
    <div>
      <h1>Functional Component Lifecycle Demo</h1>
      <LifecycleDemo />
    </div>
  );
}

export default App;
