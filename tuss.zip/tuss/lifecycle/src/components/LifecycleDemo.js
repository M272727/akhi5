import React, { useState, useEffect } from 'react';

function LifecycleDemo() {
  const [counter, setCounter] = useState(0);

  // Mounting Phase (componentDidMount)
  useEffect(() => {
    console.log('Component mounted');
    alert('Component has mounted');
    
    // Cleanup Phase (componentWillUnmount)
    return () => {
      console.log('Component will unmount');
      alert('Component will unmount');
    };
  }, []); // Empty dependency array means it only runs once when the component mounts

  // Updating Phase (componentDidUpdate)
  useEffect(() => {
    if (counter !== 0) {
      console.log(`Component updated: counter is now ${counter}`);
      alert(`Counter updated to ${counter}`);
    }
  }, [counter]); // Runs when `counter` state changes

  const incrementCounter = () => {
    setCounter(counter + 1);
  };

  const decrementCounter = () => {
    setCounter(counter - 1);
  };

  return (
    <div>
      <h2>Counter: {counter}</h2>
      <button onClick={incrementCounter}>Increment</button>
      <button onClick={decrementCounter}>Decrement</button>
    </div>
  );
}

export default LifecycleDemo;
