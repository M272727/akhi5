import React from 'react';

const TicketDisplay = ({ ticket }) => {
  return (
    <div className="ticket">
      <h2>Booking Confirmation</h2>
      <p><strong>Name:</strong> {ticket.name}</p>
      <p><strong>Movie:</strong> {ticket.movie}</p>
      <p><strong>No. of Seats:</strong> {ticket.seats}</p>
      <p><strong>Date:</strong> {ticket.date}</p>
    </div>
  );
};

export default TicketDisplay;
