import React, { useState } from 'react';

const BookingForm = ({ onBook }) => {
  const [form, setForm] = useState({
    name: '',
    movie: '',
    seats: 1,
    date: ''
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onBook(form);
    setForm({ name: '', movie: '', seats: 1, date: '' });
  };

  return (
    <form onSubmit={handleSubmit} className="form">
      <label>
        Name:
        <input type="text" name="name" value={form.name} onChange={handleChange} required />
      </label>
      <label>
        Movie:
        <input type="text" name="movie" value={form.movie} onChange={handleChange} required />
      </label>
      <label>
        No. of Seats:
        <input type="number" name="seats" min="1" value={form.seats} onChange={handleChange} required />
      </label>
      <label>
        Date:
        <input type="date" name="date" value={form.date} onChange={handleChange} required />
      </label>
      <button type="submit">Book Ticket</button>
    </form>
  );
};

export default BookingForm;
