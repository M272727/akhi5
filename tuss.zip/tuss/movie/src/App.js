import React, { useState } from 'react';
import BookingForm from './components/BookingForm';
import TicketDisplay from './components/TicketDisplay';

function App() {
  const [ticketData, setTicketData] = useState(null);

  const handleBooking = (data) => {
    setTicketData(data);
  };

  return (
    <div className="app-container">
      <h1>Movie Ticket Booking</h1>
      <BookingForm onBook={handleBooking} />
      {ticketData && <TicketDisplay ticket={ticketData} />}
    </div>
  );
}

export default App;
